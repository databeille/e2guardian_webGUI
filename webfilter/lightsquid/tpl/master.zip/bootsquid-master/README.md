A simple but cute template for Lightsquid. The Lightsquid original template is quite ugly 
and we want to get a better-looking experience for the final user (our clients), so 
we made this template based on the great Bootstrap system.

Installation
------------
Just copy the folder content into tpl/base/ folder and replace all the files.
